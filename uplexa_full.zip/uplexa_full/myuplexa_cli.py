import os
import json

WALLET_FILE = "my_wallet.json"

def create_wallet(seed=None):
    if seed:
        wallet = {"seed": seed, "balance": 0}
        with open(WALLET_FILE, "w") as f:
            json.dump(wallet, f)
        print("Wallet created with seed.")
    else:
        print("No seed provided. Run again with your seed.")

def load_wallet():
    if os.path.exists(WALLET_FILE):
        with open(WALLET_FILE, "r") as f:
            wallet = json.load(f)
        print("Wallet loaded:", wallet)
    else:
        print("No wallet file found. Please create one.")

if __name__ == "__main__":
    print("UPX Wallet CLI")
    if not os.path.exists(WALLET_FILE):
        seed = input("Enter seed phrase (or leave blank to skip): ")
        create_wallet(seed if seed else None)
    else:
        load_wallet()
